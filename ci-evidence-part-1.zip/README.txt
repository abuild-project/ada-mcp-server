CI archival evidence for abuild-project/ada-mcp-server, captured 2026-11-19 UTC.
Read manifest.json for source-ref/run/job/artifact mapping and limitations.
All 13 source heads and every one of their 25 exact-head CI runs are represented.
Provider metadata also inventories 7 dynamic Copilot review runs.
Artifacts are original GitHub validation-evidence ZIP bytes, matched to provider size and SHA-256.
Logs are UTF-8 serialization of connector-decoded job text, not raw provider download bytes.
No downloaded artifact code was executed. No release image archive is included.
Checksums describe bytes and are not independent authenticity or semantic acceptance proof.
Git refs and GitHub Actions retention are separate. This bundle does not publish private evidence.
For portable handoff, keep both ZIP parts and handoff-manifest.json together; extract each into the same new directory.
